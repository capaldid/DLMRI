# ---------------------------------------------------------
# Tensorflow DCNN Implementation
# Licensed under The MIT License [see LICENSE for details]
# Written by Cheng-Bin Jin
# Email: sbkim0407@gmail.com
# ---------------------------------------------------------
import os
import sys
import logging
import argparse
import numpy as np
import matplotlib.pyplot as plt; plt.rcdefaults()
import tensorflow as tf
from datetime import datetime

from utils import load_data
from dataset import Dataset
from Model import Model
from solver import Solver

parser = argparse.ArgumentParser(description='main')
parser.add_argument('--gpu_index', dest='gpu_index', default='0', help='gpu index if you have multiple gpus, default: 0')
parser.add_argument('--is_train', dest='is_train', default=False, action='store_true', help='training or test mode, default: False (test mode)')
parser.add_argument('--batch_size', dest='batch_size', default=8, type=int, help='batch size for one iteration, default: 8')
parser.add_argument('--dataset', dest='dataset', default='brain01', help='dataset name, default: brain01')
parser.add_argument('--learning_rate', dest='learning_rate', default=1e-3, type=float, help='learning rate, default: 2e-4')
parser.add_argument('--weight_decay', dest='weight_decay', default=1e-4, type=float, help='weight decay, default: 1e-5')
parser.add_argument('--epoch', dest='epoch', default=600, type=int, help='number of epochs, default: 600')
parser.add_argument('--print_freq', dest='print_freq', default=100, type=int, help='print frequency for loss information, default: 100')
parser.add_argument('--load_model', dest='load_model', default=None, help='folder of saved model that you wish to continue training, (e.g., 20190411-2217), default: None')
parser.add_argument('--test_filename', dest='test_filename', default=None, help='name of a specific ventilation map png file , (e.g., ./014.png), default: None')
args = parser.parse_args()

logger = logging.getLogger(__name__)  # logger
logger.setLevel(logging.INFO)


def init_logger(log_dir):
    formatter = logging.Formatter('%(asctime)s:%(name)s:%(message)s')
    # file handler
    file_handler = logging.FileHandler(os.path.join(log_dir, 'main.log'))
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.INFO)
    # stream handler
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    # add handlers
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)

    logger.info('gpu_index: {}'.format(args.gpu_index))
    logger.info('is_train: {}'.format(args.is_train))
    logger.info('batch_size: {}'.format(args.batch_size))
    logger.info('dataset: {}'.format(args.dataset))
    logger.info('learning_rate: {}'.format(args.learning_rate))
    logger.info('weight_decay: {}'.format(args.weight_decay))
    logger.info('epoch: {}'.format(args.epoch))
    logger.info('print_freq: {}'.format(args.print_freq))
    logger.info('load_model: {}'.format(args.load_model))


def make_folders(is_train=True, load_model=None, dataset=None):
    model_dir, log_dir, sample_dir, test_dir = None, None, None, None

    if is_train:
        if load_model is None:
            cur_time = datetime.now().strftime("%Y%m%d-%H%M")
            model_dir = "model/{}/{}".format(dataset, cur_time)

            if not os.path.isdir(model_dir):
                os.makedirs(model_dir)
        else:
            cur_time = load_model
            model_dir = "model/{}/{}".format(dataset, cur_time)

        sample_dir = "sample/{}/{}".format(dataset, cur_time)
        log_dir = "logs/{}/{}".format(dataset, cur_time)

        if not os.path.isdir(sample_dir):
            os.makedirs(sample_dir)

        if not os.path.isdir(log_dir):
            os.makedirs(log_dir)

    else:
        model_dir = "model/{}/{}".format(dataset, load_model)
        log_dir = "logs/{}/{}".format(dataset, load_model)
        test_dir = "test/{}/{}".format(dataset, load_model)

        if not os.path.isdir(test_dir):
            os.makedirs(test_dir)

    return model_dir, sample_dir, log_dir, test_dir


def main():
    os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu_index

    model_dir, sample_dir, log_dir, test_dir = make_folders(is_train=args.is_train,
                                                            load_model=args.load_model,
                                                            dataset=args.dataset)

    print('log_dir: {}'.format(log_dir))
    init_logger(log_dir)  # init logger
    run_config = tf.ConfigProto()
    run_config.gpu_options.allow_growth = True
    sess = tf.Session(config=run_config)

    # Initialize model and solver
    num_cross_vals = 6  # num_cross_vals have to bigger than 3 (train dataset, validation dataset, and test dataset)
    model = Model(args, name='UNet', input_dims=[256, 256, 1], output_dims=[256, 256, 1], log_path=log_dir)
    solver = Solver(sess, model)

    test(num_cross_vals, model_dir, test_dir, solver, args.test_filename)


def test(num_cross_vals, model_dir, test_dir, solver, test_filename):

    model_id = 4
    model_sub_dir = os.path.join(model_dir, 'model' + str(model_id))
    test_sub_dir = os.path.join(test_dir, 'model' + str(model_id))
    if not os.path.isdir(test_sub_dir):
        os.makedirs(test_sub_dir)

    saver = tf.train.Saver(max_to_keep=1)
    solver.init()
    if restore_model(saver, solver, model_sub_dir, model_id):  # Restore models
        logger.info(' [*] Load model ID: {} SUCCESS!'.format(model_id))
    else:
        logger.info(' [!] Load model ID: {} Failed...'.format(model_id))
        sys.exit(' [!] Cannot find checkpoint...')

    mrImgs, maskImgs = load_data([test_filename], is_test=True)
    
    preds = solver.test(mrImgs, batch_size=args.batch_size)

    # save imgs
    solver.save_imgs(preds, maskImgs, save_folder=test_sub_dir)


def restore_model(saver, solver, model_dir, model_id):
    logger.info(' [*] Reading model: {} checkpoint...'.format(model_id))

    ckpt = tf.train.get_checkpoint_state(model_dir)
    if ckpt and ckpt.model_checkpoint_path:
        ckpt_name = os.path.basename(ckpt.model_checkpoint_path)
        saver.restore(solver.sess, os.path.join(model_dir, ckpt_name))
        return True
    else:
        return False


if __name__ == '__main__':
    main()
