Please follow the steps below to run the code:

1. Download the VGG16 weights from: 
   https://github.com/ChengBinJin/MRI-to-CT-DCNN-TensorFlow

2. Download trained model from: 
   https://github.com/ChengBinJin/MRI-to-CT-DCNN-TensorFlow

3. Save the VGG16 weights file (caffe_layers_value.pickle) to ./Models_zoo/

4. Save the contents from the trained model to ./model/DLVentMRI/20200815-2145/model4/

5. We provided an example image for test: 014.png (left and right panels: specific ventilation map and mask)

6. Run >> python run_prediction.py --load_model=20200815-2145 --dataset=DLVentMRI --test_filename=./input/014.png

7. The results are save as ./test/DLVentMRI/20200815-2145/model4/000.png